package com.cfa.contacts;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactsTest {

	private ContactsDirectory contactsDirectory;

	@BeforeEach
	void setUp() throws Exception {
		contactsDirectory = new ContactsDirectory();
	}

	@Test
	public void contactsAddTest() {

		Contact contactNew = new Contact("Bob", "doe", "me@email.com", "567-467-4763");

		contactsDirectory.addContact(contactNew);

		assertNotNull(contactNew);
		assertEquals(1, contactsDirectory.getContacts().size());

		Contact contactToCheck = contactsDirectory.getContacts().first();
		
		assertEquals("Bob", contactToCheck.getFirstName());
		assertEquals("doe", contactToCheck.getLastName());
		assertEquals("me@email.com", contactToCheck.getEmailAddress());
		assertEquals("567-467-4763", contactToCheck.getPhoneNumber());
	}

	@Test
	public void contactsModifyTest() {
		Contact contactModfy = new Contact("Bob", "doe", "me2@email.com", "567-467-1111");

		contactsDirectory.modifyContact(contactModfy);

		assertNotNull(contactModfy);
		assertEquals(1, contactsDirectory.getContacts().size());

		Contact contactToCheck = contactsDirectory.getContacts().first();

		assertEquals("Bob", contactToCheck.getFirstName());
		assertEquals("doe", contactToCheck.getLastName());
		assertEquals("me2@email.com", contactToCheck.getEmailAddress());
		assertEquals("567-467-1111", contactToCheck.getPhoneNumber());
	}

	@Test
	public void contactDeleteTest() {

		Contact contact = new Contact("Bob", "doe", "me2@email.com", "567-467-1111");

		contactsDirectory.deleteContact(contact);

		assertNotNull(contact);
		assertEquals(0, contactsDirectory.getContacts().size());
	}
}
