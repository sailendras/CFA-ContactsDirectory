package com.cfa.contacts;

import java.util.Scanner;
import java.util.TreeSet;

public class ContactsDirectory {

	TreeSet<Contact> contacts = new TreeSet<Contact>();

	/**
	 * Method to add new contact
	 * 
	 * @param contact
	 * @return
	 */
	public boolean addContact(Contact contact) {
		// validate before adding the contact.
		// Need to validate emailaddress and phone number formats.
		return contacts.add(contact);
	}

	/**
	 * Deleting the existing contact
	 * 
	 * @param contact
	 */
	public void deleteContact(Contact contact) {
		// need to add validations
		if (contacts.contains(contact))
			contacts.remove(contact);
	}

	/**
	 * Modifying existing contact.
	 * 
	 * @param contact
	 */
	public void modifyContact(Contact contact) {
		// need to add validations for modification
		if (contacts.contains(contact)) {
			contacts.remove(contact);			
		} 
		contacts.add(contact);
	}

	/**
	 * List all the contacts.
	 */
	public void listContacts() {
		for (Contact contact : contacts) {
			System.out.println(contact.toString());
		}
	}
	
	@Override
	public String toString() {
		return "contacts = " + contacts + "]";
	}

	public static void main(String args[]) {
		ContactsDirectory contactsDirectory = new ContactsDirectory();

		Scanner scanner = new Scanner(System.in);
		int menu = 0;
		System.out.println("Code Challenge - Contacts Management");
		System.out.println();
		System.out.println("1. Add a Contact");
		System.out.println("2. Modify a Contact");
		System.out.println("3. Remove a Contact");
		System.out.println("4. List Contacts");
		System.out.println("5. Exit");
		boolean quit = false;
		do {
			System.out.print("Please enter your choice: ");
			menu = scanner.nextInt();
			System.out.println();

			switch (menu) {
			case 1:
				System.out.print("Enter FirstName: ");
				String fName = scanner.next();
				System.out.print("Enter LastName: ");
				String lName = scanner.next();
				System.out.print("Enter Email Address: ");
				String email = scanner.next();
				System.out.println("Enter Phone Number: ");
				String phoneNum = scanner.next();

				Contact contact = new Contact(fName, lName, email, phoneNum);
				contactsDirectory.addContact(contact);
				System.out.println("Contact added successfully.");
				break;

			case 2:
				System.out.print("Enter FirstName: ");
				String mfName = scanner.next();
				System.out.print("Enter LastName: ");
				String mlName = scanner.next();
				System.out.print("Enter Email Address: ");
				String memail = scanner.next();
				System.out.println("Enter Phone Number: ");
				String mphoneNum = scanner.next();

				Contact contactForModify = new Contact(mfName, mlName, memail, mphoneNum);
				contactsDirectory.modifyContact(contactForModify);
				System.out.println("Contact modified successfully.");
				break;

			case 3:
				System.out.print("Enter FirstName: ");
				String rfName = scanner.next();
				System.out.print("Enter LastName: ");
				String rlName = scanner.next();

				Contact rContact = new Contact(rfName, rlName);
				contactsDirectory.deleteContact(rContact);
				System.out.println("Contact removed successfully.");
				break;

			case 4:
				System.out.print("Printing all the Contacts -- ");
				contactsDirectory.listContacts();
				break;
			case 5:
				quit = true;
				System.out.print("Exiting the contacts management -- ");
				break;
			default:
				System.out.println("Invalid Entry! Please Check.");
			}
		} while (!quit);
	}

	/**
	 * @return the contacts
	 */
	public TreeSet<Contact> getContacts() {
		return contacts;
	}

}
